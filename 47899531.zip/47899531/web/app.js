(function () {
  "use strict";

  var STORE_KEY = "studymate.v1";
  var MAX_ATTACHMENTS = 4;
  var MAX_FRAMES = 8;
  var MAX_HISTORY = 20;
  var MAX_IMAGE_CHARS = 2600000;

  var el = {
    app: document.getElementById("app"),
    sidebar: document.getElementById("sidebar"),
    scrim: document.getElementById("scrim"),
    sessions: document.getElementById("sessions"),
    newSession: document.getElementById("newSession"),
    subject: document.getElementById("subject"),
    menuBtn: document.getElementById("menuBtn"),
    topbarTitle: document.getElementById("topbarTitle"),
    status: document.getElementById("status"),
    thread: document.getElementById("thread"),
    composer: document.getElementById("composer"),
    input: document.getElementById("input"),
    sendBtn: document.getElementById("sendBtn"),
    attachBtn: document.getElementById("attachBtn"),
    attachments: document.getElementById("attachments"),
    modes: document.getElementById("modes"),
    fileInput: document.getElementById("fileInput"),
    lightbox: document.getElementById("lightbox"),
    lightboxImg: document.getElementById("lightboxImg"),
    lightboxClose: document.getElementById("lightboxClose"),
    toast: document.getElementById("toast")
  };

  var state = {
    sessions: [],
    activeId: null,
    mode: null,
    pendingImages: [],
    busy: false,
    abort: null,
    drawerOpen: false
  };

  var stickToBottom = true;

  /* ---------------- helpers ---------------- */

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  var toastTimer = 0;
  function toast(message) {
    el.toast.textContent = message;
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.toast.hidden = true; }, 3200);
  }

  function setStatus(text, stateName) {
    el.status.textContent = text;
    el.status.dataset.state = stateName || "idle";
  }

  function activeSession() {
    for (var i = 0; i < state.sessions.length; i++) {
      if (state.sessions[i].id === state.activeId) return state.sessions[i];
    }
    return null;
  }

  /* ---------------- markdown ---------------- */

  function inline(text) {
    var s = esc(text);
    s = s.replace(/`([^`]+)`/g, function (_, c) { return "<code>" + c + "</code>"; });
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function (_, label, href) {
      return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">' + label + "</a>";
    });
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, "$1<em>$2</em>");
    s = s.replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,!?:;]|$)/g, "$1<em>$2</em>");
    return s;
  }

  function splitRow(line) {
    var t = line.trim();
    if (t.charAt(0) === "|") t = t.slice(1);
    if (t.charAt(t.length - 1) === "|") t = t.slice(0, -1);
    return t.split("|").map(function (c) { return c.trim(); });
  }

  function renderMarkdown(src) {
    var lines = String(src || "").replace(/\r\n?/g, "\n").split("\n");
    var out = "";
    var para = [];
    var i = 0;

    function flushPara() {
      if (para.length) {
        out += "<p>" + inline(para.join(" ")) + "</p>";
        para = [];
      }
    }

    while (i < lines.length) {
      var line = lines[i];

      if (/^\s*$/.test(line)) {
        flushPara();
        i++;
        continue;
      }

      var fence = line.match(/^\s*```([\w+-]*)\s*$/);
      if (fence) {
        flushPara();
        var code = [];
        i++;
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) { code.push(lines[i]); i++; }
        i++;
        out += "<pre><code>" + esc(code.join("\n")) + "</code></pre>";
        continue;
      }

      var head = line.match(/^(#{1,6})\s+(.*)$/);
      if (head) {
        flushPara();
        var level = Math.min(head[1].length + 1, 5);
        out += "<h" + level + ">" + inline(head[2].trim()) + "</h" + level + ">";
        i++;
        continue;
      }

      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) {
        flushPara();
        out += "<hr>";
        i++;
        continue;
      }

      if (/\|/.test(line) && i + 1 < lines.length &&
          /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$/.test(lines[i + 1])) {
        flushPara();
        var header = splitRow(line);
        i += 2;
        var rows = [];
        while (i < lines.length && /\|/.test(lines[i]) && !/^\s*$/.test(lines[i])) {
          rows.push(splitRow(lines[i]));
          i++;
        }
        var t = '<div class="table-wrap"><table><thead><tr>';
        header.forEach(function (c) { t += "<th>" + inline(c) + "</th>"; });
        t += "</tr></thead><tbody>";
        rows.forEach(function (r) {
          t += "<tr>";
          for (var c = 0; c < header.length; c++) t += "<td>" + inline(r[c] || "") + "</td>";
          t += "</tr>";
        });
        t += "</tbody></table></div>";
        out += t;
        continue;
      }

      if (/^\s*>\s?/.test(line)) {
        flushPara();
        var quote = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          quote.push(lines[i].replace(/^\s*>\s?/, ""));
          i++;
        }
        out += "<blockquote>" + inline(quote.join(" ")) + "</blockquote>";
        continue;
      }

      var bullet = line.match(/^\s*[-*\u2022]\s+(.*)$/);
      if (bullet) {
        flushPara();
        var items = [];
        while (i < lines.length) {
          var b = lines[i].match(/^\s*[-*\u2022]\s+(.*)$/);
          if (b) { items.push(b[1]); i++; continue; }
          if (/^\s{2,}\S/.test(lines[i]) && items.length) { items[items.length - 1] += " " + lines[i].trim(); i++; continue; }
          break;
        }
        out += "<ul>" + items.map(function (it) { return "<li>" + inline(it) + "</li>"; }).join("") + "</ul>";
        continue;
      }

      var ordered = line.match(/^\s*(\d{1,2})[.)]\s+(.*)$/);
      if (ordered) {
        flushPara();
        var startAt = Number(ordered[1]);
        var oitems = [];
        while (i < lines.length) {
          var o = lines[i].match(/^\s*(\d{1,2})[.)]\s+(.*)$/);
          if (o) { oitems.push(o[2]); i++; continue; }
          if (/^\s{2,}\S/.test(lines[i]) && oitems.length) { oitems[oitems.length - 1] += " " + lines[i].trim(); i++; continue; }
          break;
        }
        out += "<ol" + (startAt > 1 ? ' start="' + startAt + '"' : "") + ">" +
          oitems.map(function (it) { return "<li>" + inline(it) + "</li>"; }).join("") + "</ol>";
        continue;
      }

      para.push(line.trim());
      i++;
    }

    flushPara();
    return out;
  }

  function typeset(node) {
    var render = window.renderMathInElement;
    if (typeof render !== "function") return;
    try {
      render(node, {
        delimiters: [
          { left: "$$", right: "$$", display: true },
          { left: "\\[", right: "\\]", display: true },
          { left: "$", right: "$", display: false },
          { left: "\\(", right: "\\)", display: false }
        ],
        throwOnError: false,
        strict: false,
        ignoredTags: ["script", "noscript", "style", "textarea", "pre", "code"]
      });
    } catch (e) { /* math stays as plain text */ }
  }

  /* ---------------- storage ---------------- */

  function load() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (!raw) return;
      var data = JSON.parse(raw);
      if (!data || !Array.isArray(data.sessions)) return;
      state.sessions = data.sessions.map(function (s) {
        return {
          id: s.id,
          title: s.title || "New session",
          subject: s.subject || "General study",
          createdAt: s.createdAt || Date.now(),
          messages: Array.isArray(s.messages) ? s.messages.filter(function (m) {
            return m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string";
          }) : []
        };
      });
      if (data.subject) el.subject.value = data.subject;
      if (data.activeId && state.sessions.some(function (s) { return s.id === data.activeId; })) {
        state.activeId = data.activeId;
      }
    } catch (e) {
      state.sessions = [];
    }
  }

  function save() {
    try {
      var payload = {
        subject: el.subject.value,
        activeId: state.activeId,
        sessions: state.sessions.slice(0, 30).map(function (s) {
          return {
            id: s.id,
            title: s.title,
            subject: s.subject,
            createdAt: s.createdAt,
            messages: s.messages
              .filter(function (m) { return m.content && m.content.trim(); })
              .map(function (m) { return { role: m.role, content: m.content }; })
          };
        })
      };
      localStorage.setItem(STORE_KEY, JSON.stringify(payload));
    } catch (e) { /* quota or private mode: keep working in memory */ }
  }

  /* ---------------- sessions ui ---------------- */

  function newSession() {
    if (state.busy) {
      toast("Wait for the current answer to finish, or stop it first.");
      return;
    }
    var existing = activeSession();
    if (existing && existing.messages.length === 0) {
      el.input.focus();
      closeDrawer();
      return;
    }
    var s = {
      id: uid(),
      title: "New session",
      subject: el.subject.value,
      createdAt: Date.now(),
      messages: []
    };
    state.sessions.unshift(s);
    state.activeId = s.id;
    renderAll();
    save();
    el.input.value = "";
    autoGrow();
    el.input.focus();
    closeDrawer();
  }

  function openSession(id) {
    if (state.busy) {
      toast("Wait for the current answer to finish, or stop it first.");
      return;
    }
    state.activeId = id;
    renderAll();
    save();
    closeDrawer();
  }

  function deleteSession(id) {
    state.sessions = state.sessions.filter(function (s) { return s.id !== id; });
    if (state.activeId === id) state.activeId = state.sessions.length ? state.sessions[0].id : null;
    if (!state.sessions.length) {
      state.sessions = [];
      newSession();
      return;
    }
    renderAll();
    save();
  }

  function renderSessions() {
    var html = "";
    var listed = state.sessions.filter(function (s) { return s.messages.length > 0; });
    if (!listed.length) {
      html = '<p class="sessions-empty">No sessions yet. Ask a question or attach a photo to start.</p>';
    } else {
      listed.forEach(function (s) {
        html += '<div class="session" data-id="' + s.id + '" data-active="' + (s.id === state.activeId) + '">' +
          '<button class="session-open" type="button" data-open="' + s.id + '" title="' + esc(s.title) + '">' + esc(s.title) + "</button>" +
          '<button class="session-del" type="button" data-del="' + s.id + '" aria-label="Delete session">' +
          '<svg viewBox="0 0 24 24" fill="none"><path d="M6 7h12M10 7V5.4c0-.5.4-.9.9-.9h2.2c.5 0 .9.4.9.9V7M8 7l.7 11.2c0 .5.4.8.9.8h4.8c.5 0 .9-.3.9-.8L16 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
          "</button></div>";
      });
    }
    el.sessions.innerHTML = html;
  }

  function renderThread() {
    var s = activeSession();
    el.thread.innerHTML = "";

    if (!s || !s.messages.length) {
      el.thread.innerHTML =
        '<div class="thread-inner"><div class="intro">' +
        '<p class="eyebrow">' + esc(el.subject.value) + "</p>" +
        "<h2>What are we <em>studying</em> today?</h2>" +
        "<p>Ask a question, paste your notes, or attach a photo — or a short clip of you working — and I will walk through it with you, step by step.</p>" +
        '<div class="suggestions">' +
        suggestionHTML("photo", "Review my homework photo", "Attach a page or clip and I will mark it") +
        suggestionHTML("explain", "Explain a concept", "From first principles, with an example") +
        suggestionHTML("quiz", "Quiz me before a test", "One question at a time") +
        suggestionHTML("cards", "Turn notes into flashcards", "Front and back, ready to review") +
        "</div></div></div>";
      return;
    }

    var inner = document.createElement("div");
    inner.className = "thread-inner";
    s.messages.forEach(function (m) {
      inner.appendChild(messageEl(m));
    });
    el.thread.appendChild(inner);
    stickToBottom = true;
    scrollToBottom(true);
    settleScroll();
  }

  function suggestionHTML(action, title, desc) {
    var icons = {
      photo: '<svg viewBox="0 0 24 24" fill="none"><rect x="3.2" y="5.2" width="17.6" height="13.6" rx="3" stroke="currentColor" stroke-width="1.6"/><circle cx="9" cy="10" r="1.5" fill="currentColor"/><path d="M4.6 16.4l4.2-4a2 2 0 0 1 2.7 0l3.2 3.2M14 15.2l1.6-1.5a2 2 0 0 1 2.7 0l1.5 1.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
      explain: '<svg viewBox="0 0 24 24" fill="none"><path d="M12 18.2v-4.4M12 5.8a4.6 4.6 0 0 1 2.4 8.5v1.2h-4.8v-1.2A4.6 4.6 0 0 1 12 5.8Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M10.2 21h3.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
      quiz: '<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="3.6" width="16" height="16.8" rx="2.6" stroke="currentColor" stroke-width="1.6"/><path d="M8.4 9.2h7.2M8.4 13h7.2M8.4 16.6h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
      cards: '<svg viewBox="0 0 24 24" fill="none"><rect x="7.2" y="4" width="12.6" height="15" rx="2.4" stroke="currentColor" stroke-width="1.6"/><path d="M4.4 7.4v11.2A1.4 1.4 0 0 0 5.8 20h9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'
    };
    return '<button class="suggestion" type="button" data-action="' + action + '">' +
      '<span class="s-icon">' + icons[action] + "</span>" +
      "<span><strong>" + esc(title) + '</strong><span class="desc">' + esc(desc) + "</span></span>" +
      "</button>";
  }

  function messageEl(m) {
    if (m.role === "user") {
      var wrap = document.createElement("div");
      wrap.className = "msg msg-user";
      if (m.photos && m.photos.length) {
        var photos = document.createElement("div");
        photos.className = "bubble-photos";
        m.photos.forEach(function (photo) {
          var src = typeof photo === "string" ? photo : photo.src;
          var b = document.createElement("button");
          b.type = "button";
          b.className = "bubble-photo";
          b.dataset.zoom = src;
          b.innerHTML = '<img alt="Attached photo" src="' + src + '">' +
            (photo && photo.video ? '<span class="thumb-badge">clip</span>' : "");
          photos.appendChild(b);
        });
        wrap.appendChild(photos);
      }
      if (m.content && m.content.trim()) {
        var bubble = document.createElement("div");
        bubble.className = "bubble";
        bubble.textContent = m.content;
        wrap.appendChild(bubble);
      }
      return wrap;
    }

    var article = document.createElement("article");
    article.className = "msg msg-ai";
    article.innerHTML =
      '<div class="ai-head"><span class="dot">S</span>StudyMate</div>' +
      '<div class="prose"></div>' +
      '<div class="msg-actions"><button type="button" data-copy>Copy</button></div>';

    var prose = article.querySelector(".prose");
    if (m.pending) {
      prose.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
    } else {
      prose.innerHTML = renderMarkdown(m.content);
      typeset(prose);
    }
    m._el = article;
    m._prose = prose;
    return article;
  }

  function renderAll() {
    var s = activeSession();
    renderSessions();
    renderThread();
    el.topbarTitle.textContent = s && s.messages.length ? s.title : "New session";
    updateSendState();
  }

  /* ---------------- composer ---------------- */

  function autoGrow() {
    el.input.style.height = "auto";
    el.input.style.height = Math.min(el.input.scrollHeight, 176) + "px";
  }

  function updateSendState() {
    el.sendBtn.disabled = state.busy ? false : (!el.input.value.trim() && !state.pendingImages.length);
  }

  function renderAttachments() {
    if (!state.pendingImages.length) {
      el.attachments.hidden = true;
      el.attachments.innerHTML = "";
      return;
    }
    el.attachments.hidden = false;
    el.attachments.innerHTML = "";
    state.pendingImages.forEach(function (item, index) {
      var d = document.createElement("div");
      d.className = "thumb";
      d.innerHTML = '<img alt="Attachment ' + (index + 1) + '" src="' + item.dataUrl + '">' +
        (item.kind === "video" ? '<span class="thumb-badge">' + item.frames.length + " frames</span>" : "") +
        '<button type="button" data-remove="' + index + '" aria-label="Remove attachment">×</button>';
      el.attachments.appendChild(d);
    });
  }

  function loadBitmap(file) {
    if (window.createImageBitmap) {
      return createImageBitmap(file).catch(function () { return imageFallback(file); });
    }
    return imageFallback(file);
  }

  function imageFallback(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("decode")); };
      img.src = url;
    });
  }

  function drawFrame(source, width, height, maxSide, quality) {
    var scale = Math.min(1, maxSide / Math.max(width, height));
    var canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    var dataUrl = canvas.toDataURL("image/jpeg", quality);
    if (dataUrl.length > MAX_IMAGE_CHARS) dataUrl = canvas.toDataURL("image/jpeg", 0.7);
    return { dataUrl: dataUrl, mimeType: "image/jpeg", data: dataUrl.split(",")[1] || "" };
  }

  function sampleVideo(file, count) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var video = document.createElement("video");
      var settled = false;
      var timer = setTimeout(function () { finish(new Error("timeout")); }, 25000);

      function finish(err, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        URL.revokeObjectURL(url);
        if (err) reject(err);
        else resolve(value);
      }

      video.preload = "auto";
      video.muted = true;
      video.playsInline = true;
      video.addEventListener("error", function () { finish(new Error("decode")); });

      video.addEventListener("loadedmetadata", function () {
        var duration = video.duration;
        if (!isFinite(duration) || duration <= 0) { finish(new Error("decode")); return; }
        var span = Math.min(duration, 60);
        var times = [];
        for (var i = 0; i < count; i++) times.push(Math.max(0.04, (span * (i + 0.5)) / count));

        var frames = [];
        var index = 0;

        function grab() {
          if (index >= times.length) { finish(null, frames); return; }
          video.currentTime = times[index];
        }

        video.addEventListener("seeked", function () {
          if (settled) return;
          var w = video.videoWidth;
          var h = video.videoHeight;
          if (w && h) frames.push(drawFrame(video, w, h, 1100, 0.82));
          index++;
          grab();
        });

        grab();
      });

      video.src = url;
    });
  }

  function addFiles(fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    var room = MAX_ATTACHMENTS - state.pendingImages.length;
    if (room <= 0) {
      toast("You can attach up to " + MAX_ATTACHMENTS + " photos or clips at a time.");
      return;
    }

    files.slice(0, room).forEach(function (file) {
      var isImage = /^image\//.test(file.type);
      var isVideo = /^video\//.test(file.type);

      if (isImage) {
        loadBitmap(file).then(function (bitmap) {
          var w = bitmap.width || 0;
          var h = bitmap.height || 0;
          if (!w || !h) throw new Error("decode");
          var frame = drawFrame(bitmap, w, h, 1400, 0.86);
          state.pendingImages.push({
            kind: "image",
            dataUrl: frame.dataUrl,
            frames: [frame]
          });
          renderAttachments();
          updateSendState();
        }).catch(function () {
          toast("Could not read that photo. Try a JPEG or PNG.");
        });
        return;
      }

      if (isVideo) {
        toast("Reading clip…");
        sampleVideo(file, MAX_FRAMES).then(function (frames) {
          if (!frames.length) throw new Error("decode");
          state.pendingImages.push({
            kind: "video",
            dataUrl: frames[0].dataUrl,
            frames: frames
          });
          renderAttachments();
          updateSendState();
        }).catch(function () {
          toast("Could not read that clip here. Try an MP4 or MOV.");
        });
        return;
      }

      toast("Attach a photo or a short video clip.");
    });
  }

  /* ---------------- request ---------------- */

  function friendlyError(code, status) {
    if (code === "service_not_configured") {
      return "The tutor is not connected yet. The site owner needs to add the Gemini API key in site settings.";
    }
    if (code === "invalid_key") {
      return "The Gemini API key was rejected. Check the key in site settings.";
    }
    if (code === "rate_limited" || status === 429) {
      return "Too many requests right now. Wait a few seconds and try again.";
    }
    if (code === "blocked") {
      return "That request was blocked by the model's safety filter. Try rephrasing or a different photo.";
    }
    if (code === "payload_too_large") {
      return "That photo is too large. Try a smaller image.";
    }
    if (code === "timeout") {
      return "The answer took too long. Try again, or ask a shorter question.";
    }
    if (status === 404) {
      return "The AI service is not reachable here. This preview only shows the interface — use the published site.";
    }
    return "The tutor could not answer just now. Please try again.";
  }

  function buildPayload(attachments, history) {
    var trimmed = history.slice(-MAX_HISTORY).map(function (m) {
      return { role: m.role, content: m.content.slice(0, 8000) };
    });
    var frames = [];
    var hasClip = false;
    attachments.forEach(function (item) {
      if (item.kind === "video") hasClip = true;
      item.frames.forEach(function (frame) {
        if (frames.length < MAX_FRAMES) frames.push({ mimeType: frame.mimeType, data: frame.data });
      });
    });
    return {
      subject: el.subject.value,
      mode: state.mode,
      videoFrames: hasClip,
      images: frames,
      messages: trimmed
    };
  }

  async function runCompletion(payload, assistantMsg) {
    var prose = assistantMsg._prose;
    var text = "";
    var rafId = 0;
    var lastMath = 0;

    state.busy = true;
    state.abort = new AbortController();
    setStatus("Thinking", "busy");
    paintSendButton();
    updateSendState();

    function paint() {
      rafId = 0;
      prose.innerHTML = renderMarkdown(text);
      var now = Date.now();
      if (now - lastMath > 350) {
        lastMath = now;
        typeset(prose);
      }
      scrollToBottom(false);
    }

    function schedule() {
      if (!rafId) rafId = requestAnimationFrame(paint);
    }

    try {
      var res = await fetch("/functions/v1/app/chat", {
        method: "POST",
        credentials: "same-origin",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        signal: state.abort.signal
      });

      if (!res.ok) {
        var info = null;
        try { info = await res.json(); } catch (e) { info = null; }
        throw {
          friendly: friendlyError(info && info.error, res.status),
          retryable: res.status !== 503
        };
      }
      if (!res.body) throw { friendly: "The tutor returned no answer. Please try again.", retryable: true };

      var reader = res.body.getReader();
      var decoder = new TextDecoder();
      var buffer = "";

      while (true) {
        var chunk = await reader.read();
        if (chunk.done) break;
        buffer += decoder.decode(chunk.value, { stream: true });
        var cut;
        while ((cut = buffer.indexOf("\n\n")) >= 0) {
          var block = buffer.slice(0, cut);
          buffer = buffer.slice(cut + 2);
          var lines = block.split("\n");
          for (var k = 0; k < lines.length; k++) {
            var line = lines[k];
            if (line.indexOf("data:") !== 0) continue;
            var data = line.slice(5).trim();
            if (!data) continue;
            if (data === "[DONE]") continue;
            var parsed;
            try { parsed = JSON.parse(data); } catch (e) { continue; }
            if (parsed.error) throw { friendly: friendlyError(parsed.error), retryable: true };
            if (parsed.text) {
              text += parsed.text;
              assistantMsg.content = text;
              schedule();
            }
          }
        }
      }

      if (rafId) cancelAnimationFrame(rafId);
      paint();
      typeset(prose);
      settleScroll();

      if (!text.trim()) {
        throw { friendly: "The tutor returned an empty answer. Try rephrasing.", retryable: true };
      }
      assistantMsg.pending = false;
      setStatus("Ready", "idle");
      save();
      if (activeSession()) {
        el.topbarTitle.textContent = activeSession().title;
      }
    } catch (err) {
      if (rafId) cancelAnimationFrame(rafId);
      var aborted = err && err.name === "AbortError";

      if (aborted && text.trim()) {
        assistantMsg.content = text;
        assistantMsg.pending = false;
        paint();
        typeset(prose);
        settleScroll();
        setStatus("Stopped", "idle");
        save();
        return;
      }

      var message = aborted ? "Stopped." : (err && err.friendly) || "Something went wrong. Please try again.";

      var s = activeSession();
      if (s) {
        var idx = s.messages.indexOf(assistantMsg);
        if (idx >= 0) s.messages.splice(idx, 1);
      }

      var article = assistantMsg._el;
      if (article && article.parentNode) {
        var card = document.createElement("div");
        card.className = "error-card";
        card.innerHTML = "<span>" + esc(message) + "</span>";
        if (!aborted && !(err && err.retryable === false)) {
          var retry = document.createElement("button");
          retry.type = "button";
          retry.textContent = "Try again";
          retry.addEventListener("click", function () {
            card.parentNode && card.parentNode.removeChild(card);
            retryLast();
          });
          card.appendChild(retry);
        }
        article.parentNode.replaceChild(card, article);
      }
      setStatus(aborted ? "Ready" : "Error", aborted ? "idle" : "error");
      save();
    } finally {
      state.busy = false;
      state.abort = null;
      paintSendButton();
      updateSendState();
    }
  }

  function paintSendButton() {
    if (state.busy) {
      el.sendBtn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="8" height="8" rx="1.6" fill="currentColor"/></svg>';
      el.sendBtn.setAttribute("aria-label", "Stop");
      el.sendBtn.classList.add("is-stop");
    } else {
      el.sendBtn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M12.5 5.8 19 12l-6.5 6.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      el.sendBtn.setAttribute("aria-label", "Send message");
      el.sendBtn.classList.remove("is-stop");
    }
  }

  function retryLast() {
    var s = activeSession();
    if (!s || state.busy) return;
    var lastUser = null;
    for (var i = s.messages.length - 1; i >= 0; i--) {
      if (s.messages[i].role === "user") { lastUser = s.messages[i]; break; }
    }
    if (!lastUser) return;
    var payload = buildPayload([], s.messages);
    var assistant = { role: "assistant", content: "", pending: true };
    s.messages.push(assistant);
    var article = messageEl(assistant);
    ensureInner().appendChild(article);
    scrollToBottom(true);
    runCompletion(payload, assistant);
  }

  function ensureInner() {
    var inner = el.thread.querySelector(".thread-inner");
    if (!inner) {
      inner = document.createElement("div");
      inner.className = "thread-inner";
      el.thread.innerHTML = "";
      el.thread.appendChild(inner);
    }
    return inner;
  }

  async function send() {
    if (state.busy) {
      if (state.abort) state.abort.abort();
      return;
    }

    var text = el.input.value.trim();
    var images = state.pendingImages.slice();
    if (!text && !images.length) return;

    var s = activeSession();
    if (!s) {
      newSession();
      s = activeSession();
    }

    var userMsg = {
      role: "user",
      content: text,
      photos: images.map(function (item) {
        return { src: item.dataUrl, video: item.kind === "video" };
      })
    };
    s.messages.push(userMsg);

    if (s.messages.length === 1) {
      s.title = (text || "Photo review").slice(0, 60).replace(/\s+/g, " ");
      el.topbarTitle.textContent = s.title;
      renderSessions();
    }

    el.input.value = "";
    autoGrow();
    state.pendingImages = [];
    renderAttachments();
    updateSendState();

    var inner = ensureInner();
    if (!inner.querySelector(".msg")) {
      inner.innerHTML = "";
    }
    inner.appendChild(messageEl(userMsg));

    var history = s.messages.filter(function (m) { return !m.pending; });
    var payload = buildPayload(images, history);
    var assistant = { role: "assistant", content: "", pending: true };
    s.messages.push(assistant);
    inner.appendChild(messageEl(assistant));
    stickToBottom = true;
    scrollToBottom(true);

    runCompletion(payload, assistant);
  }

  /* ---------------- scroll ---------------- */

  function isNearBottom() {
    return el.thread.scrollHeight - el.thread.scrollTop - el.thread.clientHeight < 140;
  }

  function scrollToBottom(force) {
    if (force || stickToBottom) {
      el.thread.scrollTop = el.thread.scrollHeight;
    }
  }

  function settleScroll() {
    scrollToBottom(false);
    requestAnimationFrame(function () { scrollToBottom(false); });
    setTimeout(function () { scrollToBottom(false); }, 260);
  }

  /* ---------------- drawer ---------------- */

  function openDrawer() {
    state.drawerOpen = true;
    el.app.dataset.drawer = "open";
    el.scrim.hidden = false;
  }

  function closeDrawer() {
    state.drawerOpen = false;
    delete el.app.dataset.drawer;
    el.scrim.hidden = true;
  }

  /* ---------------- events ---------------- */

  el.composer.addEventListener("submit", function (e) {
    e.preventDefault();
    send();
  });

  el.input.addEventListener("input", function () {
    autoGrow();
    updateSendState();
  });

  el.input.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      if (state.busy) return;
      send();
    }
  });

  el.thread.addEventListener("scroll", function () {
    stickToBottom = isNearBottom();
  }, { passive: true });

  el.input.addEventListener("paste", function (e) {
    var items = e.clipboardData && e.clipboardData.items;
    if (!items) return;
    var files = [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].kind === "file" && /^image\//.test(items[i].type)) {
        var f = items[i].getAsFile();
        if (f) files.push(f);
      }
    }
    if (files.length) {
      e.preventDefault();
      addFiles(files);
    }
  });

  el.attachBtn.addEventListener("click", function () { el.fileInput.click(); });

  el.fileInput.addEventListener("change", function () {
    addFiles(el.fileInput.files);
    el.fileInput.value = "";
  });

  el.attachments.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-remove]");
    if (!btn) return;
    state.pendingImages.splice(Number(btn.dataset.remove), 1);
    renderAttachments();
    updateSendState();
  });

  el.modes.addEventListener("click", function (e) {
    var chip = e.target.closest(".chip");
    if (!chip) return;
    var mode = chip.dataset.mode;
    if (state.mode === mode) {
      state.mode = null;
      chip.setAttribute("aria-pressed", "false");
      return;
    }
    state.mode = mode;
    Array.prototype.forEach.call(el.modes.querySelectorAll(".chip"), function (c) {
      c.setAttribute("aria-pressed", String(c.dataset.mode === mode));
    });
    if (mode === "review" && !state.pendingImages.length && !el.input.value.trim()) {
      el.fileInput.click();
    }
  });

  el.thread.addEventListener("click", function (e) {
    var zoom = e.target.closest("[data-zoom]");
    if (zoom) {
      el.lightboxImg.src = zoom.dataset.zoom;
      el.lightbox.hidden = false;
      return;
    }

    var copy = e.target.closest("[data-copy]");
    if (copy) {
      var msgEl = copy.closest(".msg-ai");
      var prose = msgEl && msgEl.querySelector(".prose");
      if (prose && navigator.clipboard) {
        navigator.clipboard.writeText(prose.innerText).then(function () {
          copy.textContent = "Copied";
          setTimeout(function () { copy.textContent = "Copy"; }, 1400);
        }).catch(function () { toast("Copy failed."); });
      }
      return;
    }

    var sug = e.target.closest("[data-action]");
    if (sug) handleAction(sug.dataset.action);
  });

  el.thread.addEventListener("dragover", function (e) {
    e.preventDefault();
    el.thread.classList.add("dragging");
  });
  el.thread.addEventListener("dragleave", function () { el.thread.classList.remove("dragging"); });
  el.thread.addEventListener("drop", function (e) {
    e.preventDefault();
    el.thread.classList.remove("dragging");
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
      addFiles(e.dataTransfer.files);
      el.input.focus();
    }
  });

  function handleAction(action) {
    if (action === "photo") {
      setMode("review");
      el.fileInput.click();
      return;
    }
    if (action === "quiz") {
      setMode("quiz");
      el.input.value = "Quiz me on ";
      autoGrow();
      updateSendState();
      el.input.focus();
      el.input.setSelectionRange(el.input.value.length, el.input.value.length);
      return;
    }
    if (action === "cards") {
      setMode("cards");
      el.input.value = "Make flashcards from ";
      autoGrow();
      updateSendState();
      el.input.focus();
      el.input.setSelectionRange(el.input.value.length, el.input.value.length);
      return;
    }
    if (action === "explain") {
      setMode("explain");
      el.input.value = "Explain ";
      autoGrow();
      updateSendState();
      el.input.focus();
      el.input.setSelectionRange(el.input.value.length, el.input.value.length);
    }
  }

  function setMode(mode) {
    state.mode = mode;
    Array.prototype.forEach.call(el.modes.querySelectorAll(".chip"), function (c) {
      c.setAttribute("aria-pressed", String(c.dataset.mode === mode));
    });
  }

  el.sessions.addEventListener("click", function (e) {
    var del = e.target.closest("[data-del]");
    if (del) {
      e.stopPropagation();
      deleteSession(del.dataset.del);
      return;
    }
    var open = e.target.closest("[data-open]");
    if (open) openSession(open.dataset.open);
  });

  el.newSession.addEventListener("click", newSession);

  el.menuBtn.addEventListener("click", openDrawer);
  el.scrim.addEventListener("click", closeDrawer);

  el.subject.addEventListener("change", function () {
    var s = activeSession();
    if (s) s.subject = el.subject.value;
    save();
    if (!s || !s.messages.length) renderThread();
  });

  el.lightboxClose.addEventListener("click", function () { el.lightbox.hidden = true; });
  el.lightbox.addEventListener("click", function (e) {
    if (e.target === el.lightbox) el.lightbox.hidden = true;
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      if (!el.lightbox.hidden) { el.lightbox.hidden = true; return; }
      if (state.drawerOpen) closeDrawer();
    }
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 860 && state.drawerOpen) closeDrawer();
  });

  /* ---------------- boot ---------------- */

  load();
  if (!state.sessions.length) {
    state.sessions.push({
      id: uid(),
      title: "New session",
      subject: el.subject.value,
      createdAt: Date.now(),
      messages: []
    });
  }
  if (!state.activeId) state.activeId = state.sessions[0].id;
  var initial = activeSession();
  if (initial) el.subject.value = initial.subject || el.subject.value;

  renderAll();
  paintSendButton();
  setStatus("Ready", "idle");
  autoGrow();
  el.input.focus();
})();
