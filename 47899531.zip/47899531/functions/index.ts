import { GEMINI_API_KEY } from "./key.ts";

const MODEL_CANDIDATES = ["gemini-3.5-flash", "gemini-3-flash", "gemini-2.5-flash"];
const UPSTREAM_TIMEOUT_MS = 110000;
const MAX_BODY_CHARS = 12 * 1024 * 1024;
const MAX_MESSAGES = 24;
const MAX_TEXT_CHARS = 8000;
const MAX_IMAGES = 8;
const MAX_IMAGE_CHARS = 4000000;
const ALLOWED_MIME = new Set(["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"]);

const BASE_PROMPT = [
  "You are StudyMate, a patient one-to-one tutor for students from secondary school through university.",
  "",
  "How to teach:",
  "- Answer the actual question in the first sentence or two, then explain the reasoning.",
  "- Break problems into numbered steps and name the principle used at each step.",
  "- Use plain language and short paragraphs. Prefer concrete examples and small numbers.",
  "- Format with markdown: headings, short lists, tables for comparisons, fenced code for code.",
  "- Write mathematics in LaTeX: inline $...$ and display $$...$$.",
  "- Match depth to the question: a quick fact gets a short answer, a full problem gets worked steps.",
  "",
  "When the student attaches a photo:",
  '- Begin with one line starting "I can see:" that states what the image shows and transcribes the key question or handwriting you are working from.',
  "- Then address it. If part of the handwriting is unclear, say exactly which part is unreadable and ask, instead of inventing it.",
  "- Never claim to see details that are not visible in the image.",
  "",
  "Honesty:",
  "- If you are unsure, say so and explain what would settle it.",
  "- Do not invent citations, page numbers, statistics or sources.",
  "",
  "Style:",
  "- No filler openings, no praise padding, no restating the student's question.",
  "- Finish with one short check-for-understanding question or a concrete next step, unless the student asked for something purely factual."
].join("\n");

const MODE_PROMPTS: Record<string, string> = {
  explain: "The student chose Explain mode: build the idea from first principles, define the key terms, and give one worked example.",
  solve: "The student chose Step-by-step mode: show every step of the solution with its reasoning, then state the final answer clearly.",
  review: "The student chose Review-my-work mode: mark each visible part correct or incorrect, name the exact error and why it is wrong, then show the corrected work.",
  quiz: "The student chose Quiz mode: ask exactly one question at a time, wait for their answer, then mark it and continue. Never reveal the answer before the student responds.",
  notes: "The student chose Study-notes mode: produce compact exam-ready notes with headings, key definitions and formulas, and a short summary at the end.",
  cards: "The student chose Flashcard mode: produce 8 to 12 cards, each formatted as '**Front:** ...' on one line and '**Back:** ...' on the next, separated by '---'."
};

function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

type GeminiContent = {
  role: "user" | "model";
  parts: Array<Record<string, unknown>>;
};

function normalizeContents(rawMessages: unknown): GeminiContent[] {
  if (!Array.isArray(rawMessages)) return [];
  const merged: GeminiContent[] = [];

  for (const entry of rawMessages.slice(-MAX_MESSAGES)) {
    const message = entry as { role?: unknown; content?: unknown } | null;
    if (!message || typeof message.content !== "string") continue;
    const text = message.content.trim();
    if (!text) continue;
    const role: "user" | "model" = message.role === "assistant" ? "model" : "user";
    const last = merged[merged.length - 1];
    if (last && last.role === role) {
      last.parts.push({ text: text.slice(0, MAX_TEXT_CHARS) });
    } else {
      merged.push({ role, parts: [{ text: text.slice(0, MAX_TEXT_CHARS) }] });
    }
  }

  while (merged.length && merged[0].role !== "user") merged.shift();
  return merged;
}

function collectImageParts(rawImages: unknown): Record<string, unknown>[] | string {
  if (!Array.isArray(rawImages) || rawImages.length === 0) return [];
  const parts: Record<string, unknown>[] = [];

  for (const entry of rawImages.slice(0, MAX_IMAGES)) {
    const image = entry as { mimeType?: unknown; data?: unknown } | null;
    if (!image || typeof image.data !== "string" || typeof image.mimeType !== "string") continue;
    if (!ALLOWED_MIME.has(image.mimeType)) continue;
    if (!image.data.length || image.data.length > MAX_IMAGE_CHARS) return "payload_too_large";
    if (!/^[A-Za-z0-9+/=\r\n]+$/.test(image.data.slice(0, 128))) return "bad_image";
    parts.push({ inline_data: { mime_type: image.mimeType, data: image.data } });
  }

  return parts;
}

Deno.serve(async (request: Request) => {
  const url = new URL(request.url);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }
  if (!url.pathname.endsWith("/chat")) {
    return jsonResponse({ error: "not_found" }, 404);
  }
  if (request.method !== "POST") {
    return jsonResponse({ error: "method_not_allowed" }, 405);
  }

  const apiKey = Deno.env.get("GEMINI_API_KEY") || GEMINI_API_KEY;
  if (!apiKey) {
    return jsonResponse({ error: "service_not_configured" }, 503);
  }

  let raw: string;
  try {
    raw = await request.text();
  } catch (_error) {
    return jsonResponse({ error: "bad_request" }, 400);
  }
  if (raw.length > MAX_BODY_CHARS) {
    return jsonResponse({ error: "payload_too_large" }, 413);
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(raw);
  } catch (_error) {
    return jsonResponse({ error: "bad_request" }, 400);
  }
  if (!payload || typeof payload !== "object") {
    return jsonResponse({ error: "bad_request" }, 400);
  }

  const contents = normalizeContents(payload.messages);
  const images = collectImageParts(payload.images);
  if (typeof images === "string") {
    return jsonResponse({ error: images === "payload_too_large" ? "payload_too_large" : "bad_request" }, 413);
  }

  if (images.length) {
    const last = contents[contents.length - 1];
    if (last && last.role === "user") {
      last.parts.push(...images);
    } else {
      contents.push({ role: "user", parts: [{ text: "Please review the attached photo." }, ...images] });
    }
  }

  if (contents.length === 0) {
    return jsonResponse({ error: "bad_request" }, 400);
  }

  const mode = typeof payload.mode === "string" ? payload.mode : "";
  const subject = typeof payload.subject === "string" ? payload.subject.trim().slice(0, 40) : "";

  const systemParts = [BASE_PROMPT];
  if (subject) systemParts.push("Current subject: " + subject + ".");
  const modePrompt = MODE_PROMPTS[mode];
  if (modePrompt) systemParts.push(modePrompt);
  if (payload.videoFrames === true) {
    systemParts.push(
      "The attached images are frames sampled in order from a short video of the student working. Read them as a sequence: say what approach you can follow, then identify the first step that goes wrong, if any, and how to fix it. If the frames are too sparse to tell, say what extra frame or photo would help."
    );
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);

  let upstream: Response | null = null;
  try {
    for (const model of MODEL_CANDIDATES) {
      const attempt = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":streamGenerateContent?alt=sse",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-goog-api-key": apiKey
          },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: systemParts.join("\n\n") }] },
            contents,
            generationConfig: {
              temperature: 0.7,
              topP: 0.95,
              maxOutputTokens: 4096
            }
          }),
          signal: controller.signal
        }
      );
      if (attempt.status === 404) {
        await attempt.body?.cancel();
        continue;
      }
      upstream = attempt;
      break;
    }
  } catch (error) {
    clearTimeout(timer);
    const aborted = error instanceof Error && error.name === "AbortError";
    return jsonResponse({ error: aborted ? "timeout" : "upstream_error" }, aborted ? 504 : 502);
  }

  if (!upstream) {
    clearTimeout(timer);
    console.error("gemini upstream status 404 for all models");
    return jsonResponse({ error: "upstream_error" }, 502);
  }

  if (!upstream.ok || !upstream.body) {
    clearTimeout(timer);
    let detail = "";
    try {
      detail = await upstream.text();
    } catch (_error) {
      detail = "";
    }
    console.error("gemini upstream status", upstream.status);
    if (upstream.status === 429) return jsonResponse({ error: "rate_limited" }, 429);
    if (upstream.status === 403 || /api key not valid|API_KEY_INVALID/i.test(detail)) {
      return jsonResponse({ error: "invalid_key" }, 502);
    }
    if (upstream.status === 400 && /safety|blocked/i.test(detail)) {
      return jsonResponse({ error: "blocked" }, 400);
    }
    return jsonResponse({ error: "upstream_error" }, 502);
  }

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  const stream = new ReadableStream({
    async start(streamController) {
      const reader = upstream.body!.getReader();
      let buffer = "";

      const send = (value: unknown) => {
        streamController.enqueue(encoder.encode("data: " + JSON.stringify(value) + "\n\n"));
      };

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          let index = buffer.indexOf("\n");
          while (index >= 0) {
            const line = buffer.slice(0, index).trim();
            buffer = buffer.slice(index + 1);
            index = buffer.indexOf("\n");

            if (!line.startsWith("data:")) continue;
            const data = line.slice(5).trim();
            if (!data || data === "[DONE]") continue;

            let chunk: Record<string, unknown>;
            try {
              chunk = JSON.parse(data);
            } catch (_error) {
              continue;
            }

            const feedback = chunk.promptFeedback as { blockReason?: string } | undefined;
            if (feedback && feedback.blockReason) {
              send({ error: "blocked" });
              return;
            }

            const candidates = chunk.candidates as Array<Record<string, unknown>> | undefined;
            const candidate = candidates && candidates[0];
            if (!candidate) continue;

            const content = candidate.content as { parts?: Array<{ text?: string }> } | undefined;
            const text = (content && content.parts ? content.parts : [])
              .map((part) => (typeof part.text === "string" ? part.text : ""))
              .join("");

            if (text) send({ text });
          }
        }
        streamController.enqueue(encoder.encode("data: [DONE]\n\n"));
      } catch (_error) {
        try {
          send({ error: "upstream_error" });
        } catch (_ignored) {
          /* client already gone */
        }
      } finally {
        clearTimeout(timer);
        try {
          streamController.close();
        } catch (_ignored) {
          /* already closed */
        }
      }
    },
    cancel() {
      clearTimeout(timer);
      controller.abort();
    }
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-store, no-transform",
      "x-accel-buffering": "no"
    }
  });
});
