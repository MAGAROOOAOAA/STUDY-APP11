// Local key file. Never commit, share or zip this folder with this filled in.
export const GEMINI_API_KEY = "";
