param(
  [int]$Port = 4173,
  [string]$Root = (Join-Path $PSScriptRoot '..\web')
)

$ErrorActionPreference = 'Stop'
$Root = [System.IO.Path]::GetFullPath($Root)
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
$listener.Start()
Write-Output "serving $Root on http://127.0.0.1:$Port/"

$mime = @{
  '.html' = 'text/html; charset=utf-8'
  '.css'  = 'text/css; charset=utf-8'
  '.js'   = 'text/javascript; charset=utf-8'
  '.svg'  = 'image/svg+xml'
  '.json' = 'application/json; charset=utf-8'
  '.png'  = 'image/png'
  '.jpg'  = 'image/jpeg'
  '.jpeg' = 'image/jpeg'
  '.webp' = 'image/webp'
  '.ico'  = 'image/x-icon'
}

function Send-Response {
  param($Stream, [int]$Status, [string]$StatusText, [string]$ContentType, [byte[]]$Body)
  if ($null -eq $Body) { $Body = [byte[]]@() }
  $header = "HTTP/1.1 $Status $StatusText`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($header)
  $Stream.Write($hb, 0, $hb.Length)
  if ($Body.Length -gt 0) { $Stream.Write($Body, 0, $Body.Length) }
  $Stream.Flush()
}

while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $stream = $client.GetStream()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 2048, $true)
    $requestLine = $reader.ReadLine()
    if (-not $requestLine) { $client.Close(); continue }
    while ($true) {
      $line = $reader.ReadLine()
      if ([string]::IsNullOrEmpty($line)) { break }
    }

    $parts = $requestLine.Split(' ')
    if ($parts.Count -lt 2) { Send-Response $stream 400 'Bad Request' 'text/plain' ([System.Text.Encoding]::UTF8.GetBytes('bad request')); $client.Close(); continue }

    $method = $parts[0]
    $target = $parts[1]
    $path = $target.Split('?')[0].Split('#')[0]
    $path = [System.Uri]::UnescapeDataString($path)

    if ($method -ne 'GET' -and $method -ne 'HEAD') {
      Send-Response $stream 405 'Method Not Allowed' 'text/plain' ([System.Text.Encoding]::UTF8.GetBytes('method not allowed'))
      $client.Close()
      continue
    }

    if ($path -eq '/' -or $path -eq '') { $path = '/index.html' }
    $candidate = [System.IO.Path]::GetFullPath((Join-Path $Root $path.TrimStart('/')))

    if (-not $candidate.StartsWith($Root, [System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      Send-Response $stream 404 'Not Found' 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('not found'))
      $client.Close()
      continue
    }

    $ext = [System.IO.Path]::GetExtension($candidate).ToLowerInvariant()
    $ct = $mime[$ext]
    if (-not $ct) { $ct = 'application/octet-stream' }
    $body = [System.IO.File]::ReadAllBytes($candidate)
    Send-Response $stream 200 'OK' $ct $body
  } catch {
    try { Send-Response $stream 500 'Internal Server Error' 'text/plain' ([System.Text.Encoding]::UTF8.GetBytes('error')) } catch { }
  } finally {
    $client.Close()
  }
}
